
function hideText()
{
	$("footer").hide();
	
}
